#include "Utils.h"


bool shouldLog(int x) {
    return x <= log_level;
}
